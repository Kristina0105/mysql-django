from django.contrib import admin

from cities.models import Restaurants

admin.site.register(Restaurants)
